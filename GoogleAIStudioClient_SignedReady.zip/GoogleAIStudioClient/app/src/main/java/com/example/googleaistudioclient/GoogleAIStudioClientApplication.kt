
package com.example.googleaistudioclient

import android.app.Application
import dagger.hilt.android.HiltAndroidApp

@HiltAndroidApp
class GoogleAIStudioClientApplication : Application() {}

