
package com.example.googleaistudioclient

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.google.ai.client.generativeai.GenerativeModel
import com.google.ai.client.generativeai.type.content
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.launch
import javax.inject.Inject

@HiltViewModel
class MainViewModel @Inject constructor() : ViewModel() {

    private val _chatMessages = MutableStateFlow<List<String>>(emptyList())
    val chatMessages: StateFlow<List<String>> = _chatMessages

    private val _isLoading = MutableStateFlow(false)
    val isLoading: StateFlow<Boolean> = _isLoading

    private lateinit var generativeModel: GenerativeModel

    fun initializeChat(apiKey: String, systemPrompt: String?) {
        generativeModel = GenerativeModel(
            modelName = "gemini-pro",
            apiKey = apiKey
        )
        viewModelScope.launch {
            if (!systemPrompt.isNullOrBlank()) {
                val chat = generativeModel.startChat(
                    history = listOf(
                        content(role = "user") { text(systemPrompt) },
                        content(role = "model") { text("ОК. Я готовий.") }
                    )
                )
                _chatMessages.value = _chatMessages.value + "System: $systemPrompt"
                _chatMessages.value = _chatMessages.value + "AI: ОК. Я готовий."
            }
        }
    }

    fun sendMessage(message: String) {
        viewModelScope.launch {
            _isLoading.value = true
            _chatMessages.value = _chatMessages.value + "User: $message"
            try {
                val chat = generativeModel.startChat()
                val response = chat.sendMessage(message)
                response.text?.let { 
                    _chatMessages.value = _chatMessages.value + "AI: $it"
                }
            } catch (e: Exception) {
                _chatMessages.value = _chatMessages.value + "Error: ${e.message}"
            }
            _isLoading.value = false
        }
    }
}



import kotlinx.coroutines.flow.MutableSharedFlow
import kotlinx.coroutines.flow.SharedFlow



    private val _speakEvent = MutableSharedFlow<String>()
    val speakEvent: SharedFlow<String> = _speakEvent



    fun speak(text: String) {
        viewModelScope.launch {
            _speakEvent.emit(text)
        }
    }



import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.util.Base64
import android.util.Log



    private val _generatedImage = MutableStateFlow<Bitmap?>(null)
    val generatedImage: StateFlow<Bitmap?> = _generatedImage

    fun generateImage(prompt: String) {
        viewModelScope.launch {
            _isLoading.value = true
            try {
                val imageGenerativeModel = GenerativeModel(
                    modelName = "gemini-pro-vision",
                    apiKey = generativeModel.apiKey // Use the same API key as for chat
                )
                val response = imageGenerativeModel.generateContent(prompt)
                response.candidates.firstOrNull()?.content?.parts?.firstOrNull()?.blob?.data?.let {
                    val decodedString = Base64.decode(it.toByteArray(), Base64.DEFAULT)
                    _generatedImage.value = BitmapFactory.decodeByteArray(decodedString, 0, decodedString.size)
                }
            } catch (e: Exception) {
                Log.e("ImageGeneration", "Error generating image: ${e.message}")
            }
            _isLoading.value = false
        }
    }

