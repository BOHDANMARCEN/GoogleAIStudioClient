
rootProject.name = "GoogleAIStudioClient"
include(":app")

